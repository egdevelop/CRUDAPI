const express = require("express");
const mysql = require("mysql");
const router = express.Router();

const db = mysql.createConnection({
  host: "127.0.0.1",
  user: "root",
  password: "",
  database: "list_app",
});
db.connect((err) => {
  if (err) {
    console.log("error connecting: " + err.stack);
    return;
  }
  console.log("success");
});
//READ ALL
router.get("/", (req, res, next) => {
  db.query("SELECT * FROM user", (error, results) => {
    res.json(results);
  });
});
//READ ONE
router.get("/:id", (req, res, next) => {
  const { id } = req.params;
  db.query("SELECT * FROM user where id = ?", [id], (error, results) => {
    res.json(results);
  });
});
//CREATE ONE
router.post("/", (req, res, next) => {
  const { username, pw } = req.body;
  db.query(
    "INSERT INTO user (username, pw) VALUES (?,?)",
    [username, pw],
    (error, results) => {
      res.json({
        massage: "sukses",
      });
    }
  );
});
//UPDATE ONE
router.put("/:id", (req, res, next) => {
  const { username, pw } = req.body;
  const { id } = req.params;
  db.query(
    "UPDATE user set username = ? , pw = ? where id = ?",
    [username, pw, id],
    (error, results) => {
      res.json({
        massage: "Data di update",
      });
    }
  );
});

router.delete("/:id", (req, res, next) => {
  const { id } = req.params;
  db.query("DELETE from user where id=?", [id], (error, results) => {
    res.json({
      massage: "Data di delete",
    });
  });
});

module.exports = router;
